import React from 'react';

function Dashboard() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-center">🛒 Grocery Manager</h1>
    </div>
  );
}

export default Dashboard;