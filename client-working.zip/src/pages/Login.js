import React from 'react';

function Login() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Login Page</h2>
    </div>
  );
}

export default Login;