import React from 'react';

function Register() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Register Page</h2>
    </div>
  );
}

export default Register;